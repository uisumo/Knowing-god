jQuery(document).ready(function ($) {
    "use strict";
    /*slick nav - responsive navbar*/
    $(".selectpicker").select2();
});