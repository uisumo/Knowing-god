<!-- Modal -->
<div class="modal fade" id="genericModal" tabindex="-1" role="dialog" aria-labelledby="genericModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="genericModalLabel">&nbsp;</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<form action="" method="post" name="frmGeneric" id="frmGeneric">
			<div class="modal-body">
				<div id="genericModalContent"></div>
			</div>
			<div class="modal-footer">
				<div id="genericModalFooter"></div>
			</div>
			</form>
			<div id="generic_other_list"></div>
		</div>
	</div>
</div>
<!-- /Modal -->
