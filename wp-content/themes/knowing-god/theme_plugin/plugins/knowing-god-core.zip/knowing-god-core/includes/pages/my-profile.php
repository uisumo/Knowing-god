<div class="container">
	<div class="row">
		<div class="col-sm-2"></div>
		<div class="col-sm-8" style="max-width: 640px">
			<div class="row">
				<div class="col-sm-12">
					<div class="profile-card" style="background: url(<?php echo esc_url( KNOWING_GOD_PLUGIN_URL ); ?>images/pbg.png) center no-repeat;">
						<div class="corner-ribbon">Subscriber</div>
						<button class="btn btn-yellow btn-fund">Fund another <br>part of the Pathway!</button>
						<div class="media">
							<div class="profile-img">
								<img src="https://goo.gl/qDzexi" alt="">
								<ul class="top-icnset">
									<li class="text-green"><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
								</ul>
								<ul class="right-icnset">
									<li class="text-blue"><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
								</ul>
								<ul class="left-icnset">
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li><i class="fa fa-map-marker"></i></li>
									<li class="text-yellow"><i class="fa fa-map-marker"></i></li>
								</ul>
								<a href="#" class="profile-mgs-notify">1</a>
							</div>
							<div class="media-body ml-5">
								<p>Henzekiah R. Borrett</p>
								<p>Joined September 29, 2017</p>
								<p>Completer a section!</p>
								<p>Join a Group!</p>
								<p>Facilitate a Group!</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<div role="tablist" class="expand-card">
						<div class="card">
							<div class="card-header" role="tab" id="headingOne">
								<h4 class="mb-0">
									<a data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
										<span class="dc-caret"><i class="fa fa-caret-down" aria-hidden="true"></i></span> Profile Diamond</a>
								</h4>
							</div>
							<div id="collapseOne" class="collapse show" role="tabpanel" aria-labelledby="headingOne">
								<div class="card-body">
									<div class="row">
										<div class="col-sm-4">
											<div class="join-btn join-btn-title">
												  Join a <span class="text-blue">Group</span><br> <img src="<?php echo esc_url( KNOWING_GOD_PLUGIN_URL ); ?>images/plus.svg" width="38" height="38" alt="">
											  </div>
										</div>
										<div class="col-sm-4">
											<div class="join-btn join-btn-title">
												  Pathway<span class="text-green">Start</span><br> <img src="<?php echo esc_url( KNOWING_GOD_PLUGIN_URL ); ?>images/plus.svg" width="38" height="38" alt="">
											  </div>
										</div>
										<div class="col-sm-4">
											<div id="tableContent" style="display:none">
												<div class="pathway-list">
													<h4>Pathway<span class="text-green">Start</span></h4>
													<ol class="ol">
														<li>Good News <span class="fa fa-check-circle pull-right text-green"></span></li>
														<li>Encountering Jesus <span class="fa fa-check-circle pull-right text-green"></span></li>
														<li>G.L.O. <span class="fa fa-check-circle pull-right text-green"></span></li>
														<li>3 Easy Questions <span class="fa fa-check-circle pull-right"></span></li>
														<li>In My Name <span class="fa fa-check-circle pull-right"></span></li>
													</ol>
												</div>
											</div>
											<div class="tableContent" style="display:none">
												<div class="pathway-list">
													<h4>Pathway<span class="text-green">Start</span></h4>
													<ol class="ol">
														<li>Good News <span class="fa fa-check-circle pull-right text-blue"></span></li>
														<li>Encountering Jesus <span class="fa fa-check-circle pull-right text-blue"></span></li>
														<li>G.L.O. <span class="fa fa-check-circle pull-right text-yellow"></span></li>
														<li>3 Easy Questions <span class="fa fa-check-circle pull-right"></span></li>
														<li>In My Name <span class="fa fa-check-circle pull-right"></span></li>
													</ol>
												</div>
											</div>

											<div class="profile-diamond">
												<div class="diamond dimond-1" id="popupReturn">
													<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 305.05 209.9"><defs><style>.cls-1{stroke:#000;stroke-miterlimit:10;stroke-width:2px;fill:url(#linear-gradient);}</style><linearGradient id="linear-gradient" x1="152.75" y1="208.9" x2="152.75" y2="1" gradientUnits="userSpaceOnUse"><stop offset="0.13" stop-color="#00a17e"/><stop offset="0.56" stop-color="#fff"/></linearGradient></defs><title>Asset 4</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polygon class="cls-1" points="158 1 2 208.9 210 208.9 303.5 1 158 1"/></g></g></svg>
												</div>
												<div class="diamond dimond-2 popupReturn">
													<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 294.12 209.9"><defs><style>.cls-2{stroke:#000;stroke-miterlimit:10;stroke-width:2px;fill:url(#diamond2);}</style><linearGradient id="diamond2" x1="147.03" y1="208.9" x2="147.03" y2="1" gradientUnits="userSpaceOnUse"><stop offset="0.04" stop-color="#00a3c3"/><stop offset="0.04" stop-color="#09a6c5"/><stop offset="0.05" stop-color="#37b7d0"/><stop offset="0.06" stop-color="#62c6da"/><stop offset="0.07" stop-color="#88d4e3"/><stop offset="0.08" stop-color="#a8e0eb"/><stop offset="0.09" stop-color="#c4eaf1"/><stop offset="0.11" stop-color="#daf2f6"/><stop offset="0.13" stop-color="#ebf8fa"/><stop offset="0.15" stop-color="#f6fcfd"/><stop offset="0.18" stop-color="#fdfeff"/><stop offset="0.26" stop-color="#fff"/></linearGradient></defs><title>Asset 5</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polygon class="cls-2" points="84.58 1 1.48 208.9 292.58 208.9 198.98 1 84.58 1"/></g></g></svg>
												</div>
												<div class="diamond dimond-3 popupReturn">
													<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 305.2 211"><defs><style>.cls-3{stroke:#000;stroke-miterlimit:10;stroke-width:2px;fill:url(#diamond3);}</style><linearGradient id="diamond3" x1="152.37" y1="210" x2="152.37" y2="1" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#f8b600"/><stop offset="0.1" stop-color="#fff"/></linearGradient></defs><title>Asset 3</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polygon class="cls-3" points="1.57 1 141.57 1 303.17 210 98.57 210 1.57 1"/></g></g></svg>
												</div>
												<div class="diamond dimond-4">
													<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 347.75 454.85"><defs><style>.cls-4{stroke:#000;stroke-miterlimit:10;stroke-width:2px;fill:url(#diamond4);}</style><linearGradient id="diamond4" x1="174.13" y1="1.01" x2="174.13" y2="449.91" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#f8b600"/><stop offset="0.45" stop-color="#fff"/></linearGradient></defs><title>Asset 2</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polygon class="cls-4" points="137.73 1.01 2.53 449.91 345.73 2.71 137.73 1.01"/></g></g></svg>
												</div>
												<div class="diamond dimond-5">
													<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 304.14 474.58"><defs><style>.cls-5{stroke:#000;stroke-miterlimit:10;stroke-width:2px;fill:url(#diamond5);}</style><linearGradient id="diamond5" x1="155.61" y1="3.3" x2="155.61" y2="471.34" gradientTransform="translate(-3.57 2.36) rotate(-0.87)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#f8b600"/><stop offset="0.1" stop-color="#fff"/></linearGradient></defs><title>Asset 6</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polygon class="cls-5" points="1.38 5.62 302.78 1.02 157.18 471.32 1.38 5.62"/></g></g></svg>
												</div>
												<div class="diamond dimond-6">
													<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 347.72 454.94"><defs><style>.cls-6{stroke:#000;stroke-miterlimit:10;stroke-width:2px;fill:url(#diamond6);}</style><linearGradient id="diamond6" x1="173.56" y1="1.01" x2="173.56" y2="449.91" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#f8b600"/><stop offset="0.1" stop-color="#fff"/></linearGradient></defs><title>Asset 7</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polygon class="cls-6" points="2.02 2.71 206.51 1.01 345.12 449.91 2.02 2.71"/></g></g></svg>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<h4 class="mb-0">My Cources</h4>
							</div>
							<div class="card-body">
								<div class="media">
									<div class="join-btn">
										<img src="<?php echo esc_url( KNOWING_GOD_PLUGIN_URL ); ?>images/plus.svg" width="27" height="27" alt="">
									</div>
									<div class="media-body vertical-align">
										<p class="course-text">Learn about discipleship, Jesus and much more. Join a course today!</p>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header card-center-header" role="tab" id="headingTwo">
								<h4 class="mb-0">
									<a class="collapsed" data-toggle="collapse" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
										<span class="dc-caret"><i class="fa fa-caret-down" aria-hidden="true"></i></span>Finish Your.....</a>
								</h4>
							</div>
							<div id="collapseTwo" class="collapse" role="tabpanel" aria-labelledby="headingTwo">
								<div class="card-body">
									<div class="row">
										<div class="col-sm-7">
											<h2 class="task-head text-right">Romans 5 Blog Series</h2>
										</div>
										<div class="col-sm-5">
											<div class="btn-outline blue-white-gridient">20% Complete</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<h4 class="mb-0">My Groups</h4>
							</div>
							<div class="card-body">
								<div class="media">
									<div class="join-btn">
										<img src="<?php echo esc_url( KNOWING_GOD_PLUGIN_URL ); ?>images/plus.svg" width="27" height="27" alt="">
									</div>
									<div class="media-body vertical-align">
										<p class="course-text mt-3">Journey the Pathway with Others!</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">


				</div>
			</div>
		</div>
		<div class="col-sm-2"></div>

	</div>
</div>
<script>
	
	jQuery( document ).ready(function( $ ) {

		var popupEvent = function() {}

		$('.popupReturn').hunterPopup({
			width: '240px',
			height: '100%',
			title: "Pathway",
			content: $('.tableContent'),

			event: popupEvent
		});
		$('#popupReturn').hunterPopup({
			width: '240px',
			height: '100%',
			title: "Pathway",
			content: $('#tableContent'),

			event: popupEvent
		});

	});

</script>