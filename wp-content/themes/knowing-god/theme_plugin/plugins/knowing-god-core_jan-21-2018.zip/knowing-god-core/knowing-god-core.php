<?php
/**
 * Plugin Name: Knowing God Core
 * Plugin URI:https://digisamaritan.com/
 * Description: This plugin will provide short codes and widgets for the Knowing God theme.
 * Version: 1.0.0
 * Author: Digisamaritan
 * Author URI: https://digisamaritan.com/
 * Text Domain: knowing-god
*/

define( 'KNOWING_GOD_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

// Plugin URL.
define( 'KNOWING_GOD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require KNOWING_GOD_PLUGIN_PATH . 'includes/metabox.php';

require KNOWING_GOD_PLUGIN_PATH . 'includes/aq-resizer.php';

require KNOWING_GOD_PLUGIN_PATH . 'includes/shortcodes.php';

if ( ! function_exists( 'knowing_god_signin' ) ) :
	/**
	 * [knowing_god_signin]
	 * @param array $atts - Attributes
	 * @return shortcode page
	 */
	function knowing_god_signin( $atts ){		
		include_once( KNOWING_GOD_PLUGIN_PATH . '/includes/pages/login.php' );
	}
endif;
add_shortcode( 'knowing_god_signin', 'knowing_god_signin' );

if ( ! function_exists( 'knowing_god_register' ) ) :
	/**
	 * [knowing_god_signin]
	 * @param array $atts - Attributes
	 * @return shortcode page
	 */
	function knowing_god_register( $atts ){		
		include_once( KNOWING_GOD_PLUGIN_PATH . '/includes/pages/register.php' );
	}
endif;
add_shortcode( 'knowing_god_register', 'knowing_god_register' );

if ( ! defined( 'knowing_god_is_user' ) ) :
	/**
	 * This function check whenter the user is belongs to the particualte user role or not
	 * @param string $user_role - Role.
	 */
	function knowing_god_is_user( $user_role ) {
		$current_user = ( array ) wp_get_current_user();
		$roles = $status_links = array();
		foreach ( $current_user['roles'] as $role ) {
			$roles[] = trim( $role );
		}
		if ( in_array( $user_role, $roles ) )
			return true;
		else
			return false;
	}
endif;
