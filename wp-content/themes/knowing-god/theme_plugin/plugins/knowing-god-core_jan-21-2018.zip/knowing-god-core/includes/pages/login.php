<?php
$rememberme = ! empty( $_POST['rememberme'] );
?>
<div class="container">
    <div class="row">
        <div class="col-md-12 mx-auto mt-5">
            <div class="panel panel-default kg-login">
                
				<div class="panel-heading"><h2 class="mb-4">Welcome back!</h2></div>
				
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="">
                        <input type="hidden" name="knowing_god_login_nonce" value="<?php echo wp_create_nonce( 'knowing-god-login-nonce' ); ?>"/>
						<input type="hidden" name="knowing_god_action" value="user_login"/>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label"><?php esc_html_e( 'Username / E-Mail', 'knowing-god' ); ?></label>
                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="email" value="" required="" autofocus="" placeholder="<?php esc_html_e( 'Username / E-Mail', 'knowing-god' ); ?>">
							</div>
                        </div>

                        <div class="form-group">
                            <label for="password" class="col-md-4 control-label"><?php esc_html_e( 'Password', 'knowing-god' ); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required="" placeholder="<?php esc_html_e( 'Password', 'knowing-god' ); ?>">

                                                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input id="rememberme" type="checkbox" name="rememberme" value="forever" <?php checked( $rememberme ); ?>><?php esc_html_e( 'Remember Me', 'knowing-god' ); ?>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-info"><?php esc_html_e( 'Login', 'knowing-god' ); ?>
                                </button>

                                <a class="btn btn-link" href="http://108.61.222.129/password/reset">
                                    Forgot Your Password?
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
