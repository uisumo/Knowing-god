<div class="container">
    <div class="row">
        <div class="col-md-12 mx-auto mt-5">
            <div class="panel panel-default kg-register">
                <div class="panel-heading"><h2 class="mb-4">Please Sign Up</h2></div>
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="http://108.61.222.129/register">
                        <input type="hidden" name="_token" value="bwtKlnNVUx3DWFYAIqRlKVH57NcWPu3kQaMn3xcM">

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="">
                                <input id="name" type="text" class="form-control" name="name" value="" required="" autofocus="">

                                                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="">
                                <input id="email" type="email" class="form-control" name="email" value="" required="">

                                                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="">
                                <input id="password" type="password" class="form-control" name="password" required="">

                                                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required="">
                            </div>
                        </div>

                       
                        <div class="input-group mb-2">
                            <span class="input-group-addon">
                                <input class="mr-2" type="checkbox" aria-label="Checkbox for following text input"> 
                            <a href="/privacy"> I have read the Privacy Statement</a></span>
                            <input type="text" class="form-control" aria-label="Text input with checkbox">
                        </div>
                             
                         
                        <div class="input-group mb-2">
                            <span class="input-group-addon"> 
                                <input class="mr-2" type="checkbox" aria-label="Checkbox for following text input"> 
                            <a href="/termsofservice"> I have read the Terms of Use</a></span>
                            <input type="text" class="form-control" aria-label="Text input with checkbox">
                        </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        Sign Up!
                                    </button>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
